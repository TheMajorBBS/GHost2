#!/bin/bash

wget -O GHost.dll https://github.com/rickparrish/GHost/raw/master/bin/Release/GHost.dll
wget -O GHostConfig.exe https://github.com/rickparrish/GHost/raw/master/bin/Release/GHostConfig.exe
wget -O GHostConsole.exe https://github.com/rickparrish/GHost/raw/master/bin/Release/GHostConsole.exe
wget -O GHostGUI.exe https://github.com/rickparrish/GHost/raw/master/bin/Release/GHostGUI.exe
wget -O GHostService.exe https://github.com/rickparrish/GHost/raw/master/bin/Release/GHostService.exe
wget -O RMLib.dll https://github.com/rickparrish/GHost/raw/master/bin/Release/RMLib.dll
wget -O RMLibUI.dll https://github.com/rickparrish/GHost/raw/master/bin/Release/RMLibUI.dll
wget -O Upgrade.exe https://github.com/rickparrish/GHost/raw/master/bin/Release/Upgrade.exe
